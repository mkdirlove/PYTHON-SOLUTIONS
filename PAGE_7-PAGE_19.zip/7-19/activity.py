#!/usr/bin/python3

#####################
# PAGE 7
#####################

a = 2
print(type(a))
# Output: <type 'int'>
b = 9223372036854775807
print(type(b))
# Output: <type 'int'>
pi = 3.14
print(type(pi))
# Output: <type 'float'>
c = 'A'
print(type(c))
# Output: <type 'str'>
name = 'John Doe'
print(type(name))
# Output: <type 'str'>
q = True
print(type(q))
# Output: <type 'bool'>
x = None
print(type(x))
# Output: <type 'NoneType'>

#####################
# PAGE 8
#####################

a, b, c = 1, 2, 3
print(a, b, c)
# Output: 1 2 3
a, b, _ = 1, 2, 3
print(a, b)
# Output: 1, 2
a = b = c = 1
print(a, b, c)
# Output: 1 1 1
a = b = c = 1
print(a, b, c)
# Output: 1 1 1

#####################
# PAGE 9
#####################

a = b = c =1 # all three names a, b and c refer to same int object with value 1
print(a, b, c)
# Output: 1 1
b = 2       # b now refers to another int object, one with a value of 2
print(a, b, c)
# Output: 1 2 1    # so output is as expected.

x = y = [7, 8, 9]
# x and y refer to the same list object just created, [7, 8, 9]
x = [13, 8, 9]
# x now refers to a different list object just created, [13, 8, 9]
print(y)
# y still refers to the list it was first assigned
# Output: [7, 8, 9]

x = y = [7, 8, 9]      # x and y are two different names for the same list object just created, [7, 8, 9]
x[0] = 13              # we are updating the value of the list [7, 8, 9] through one of its names, x in this case
print(y)               # printing the value of the list using its other name
# Output: [13, 8, 9]   # hence, naturally the change is reflected

x = [1, 2, [3, 4, 5], 6, 7] # this is nested list
print(x[2])
# Output: [3, 4, 5]
print(x[2][1])
# Output: 4

a = 2
print(a)
# Output: 2
a = "New value"
print(a)
# Output: New value

#####################
# PAGE 11
#####################

issubclass(bool, int) # True
isinstance(True, bool) # True
isinstance(False, bool) # True

True + False == 1 # 1 + 0 == 1
True * True == 1 # 1 * 1 == 1

#   INTEGERS
a = 2
b = 100
c = 123456789
d = 38563846326424324

# FLOATING POINTS
a = 2.0
b = 100.e0
c = 123456789.e1

#####################
# PAGE 12
#####################

# LIST
a = [1, 2, 3]
b = ['a', 1, 'python', (1, 2), [1, 2]]
b[2] = 'something else' # allowed

# SET
a = {1, 2, 'a'}

#####################
# PAGE 13
#####################

# DICTIONARY
a = {
1: 'one',
2: 'two'
}

b = {
'a': [1, 2, 3],
'b': 'a string'
}

a = '123'
print(type(a))
# Out: <class 'str'>
b = 123
print(type(b))
# Out: <class 'int'>

#####################
# PAGE 14
#####################

i = 7
if isinstance(i, int):
    i += 1
elif isinstance(i, str):
    i = int(i)
    i += 1

x = None
if x is None:
    print('Not a surprise, I just defined x as None.')

a = '123'
b = int(a)

a = '123.456'
b = float(a)
c = int(a)
d = int(b) # ValueError: invalid literal for int() with base 10: '123.456'

a = 'hello'
list(a) # ['h', 'e', 'l', 'l', 'o']
set(a)
# {'o', 'e', 'l', 'h'}
tuple(a) # ('h', 'e', 'l', 'l', 'o')

normal = 'foo\nbar'  # foo bar
escaped = 'foo\\nbar'# foo\nbar
raw = r'foo\nbar' # foo\nbar

#####################
# PAGE 15
#####################

def f(m):
    m.append(3) # adds a number to the list. This is a mutation.
    x = [1, 2]
    f(x)
    x == [1, 2] # False now, since an item was added to the list

def bar():
    x = (1, 2)
    g(x)
    x == (1, 2) # Will always be True, since no function can change the object (1, 2)

#####################
# PAGE 16
#####################

int_list = [1, 2, 3]
string_list = ['abc', 'defghi']
mixed_list = [1, 'abc', True, 2.34, None]
nested_list = [['a', 'b', 'c'], [1, 2, 3]]

names = ['Alice', 'Bob', 'Craig', 'Diana', 'Eric']
print(names[0]) # Alice
print(names[2]) # Craig
print(names[-1]) # Eric
print(names[-4]) # Bob

names[0] = 'Ann'
print(names)
# Outputs ['Ann', 'Bob', 'Craig', 'Diana', 'Eric']

names = ['Alice', 'Bob', 'Craig', 'Diana', 'Eric']
names.append("Sia")
print(names)
# Outputs ['Alice', 'Bob', 'Craig', 'Diana', 'Eric', 'Sia']

names.insert(1, "Nikki")
print(names)
# Outputs ['Alice', 'Nikki', 'Bob', 'Craig', 'Diana', 'Eric', 'Sia']

names.remove("Bob")
print(names) # Outputs ['Alice', 'Nikki', 'Craig', 'Diana', 'Eric', 'Sia']
name.index("Alice")
len(names)
names.pop() # Outputs 'Sia'

#####################
# PAGE 17
#####################

a = [1, 1, 1, 2, 3, 4]
a.count(1)

a.reverse()
[4, 3, 2, 1, 1, 1]
# or
a[::-1]
[4, 3, 2, 1, 1, 1]

for element in my_list:
    print (element)

ip_address = ('10.20.30.40', 8080)
one_member_tuple = ('Only member',)
one_member_tuple = 'Only member', # No brackets
one_member_tuple = tuple(['Only member'])

#####################
# PAGE 18
#####################

# DICTIONARIES
state_capitals = {
'Arkansas': 'Little Rock',
'Colorado': 'Denver',
'California': 'Sacramento',
'Georgia': 'Atlanta'
}

ca_capital = state_capitals['California']
for k in state_capitals.keys():
    print('{} is the capital of {}'.format(state_capitals[k], k))

# SETS
first_names = {'Adam', 'Beth', 'Charlie'}
my_list = [1,2,3]
my_set = set(my_list)

if name in first_names:
    print(name)

#####################
# PAGE 19
#####################

state_capitals = {
'Arkansas': 'Little Rock',
'Colorado': 'Denver',
'California': 'Sacramento',
'Georgia': 'Atlanta'
}

from collections import defaultdict
state_capitals = defaultdict(lambda: 'Boston')
state_capitals['Arkansas'] = 'Little Rock'
state_capitals['California'] = 'Sacramento'
state_capitals['Colorado'] = 'Denver'
state_capitals['Georgia'] = 'Atlanta'
state_capitals['Alabama']
state_capitals['Arkansas']
