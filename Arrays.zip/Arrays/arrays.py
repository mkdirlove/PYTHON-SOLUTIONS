#!/usr/bin/python3

#############################################
# ARRAY EXAMPLES BY JAYSON SAN BUENAVENTURA #
#############################################

# LIBRARIES
import array as arr
import time
import os

# ADDING ELEMENTS
def add_elements():
    os.system("clear")
    print("Adding Elements")
    print("======================")
    print("1. Append\n2. Insert\n3. Extend\n4. Back")
    print("======================")
    opt = input("Choose: ")

# APPEND()
    if opt == "1":
        ap = arr.array('i', [1, 2, 3, 4, 5])
        print("Append method")
        print("======================")
        print(ap)
        print("Index:      0  1  2  3  4 ")
        print("Let\'s add number 6 in index 5")
        ap.append(6)
        print(ap)
        print("Index:      0  1  2  3  4  5")
        time.sleep(5)
        add_elements()

# INSERT()
    elif opt == "2":
        ins = arr.array('i', [1, 2, 3, 4, 5, 7])
        print("Insert method")
        print("======================")
        print(ins)
        print("Index:      0  1  2  3  4  5  6")
        print("Let\'s insert number 6 in index 5")
        ins.insert(5, 6)
        print(ins)
        print("Index:      0  1  2  3  4  5  6")
        time.sleep(5)
        add_elements()

# EXTEND()
    elif opt == "3":
        ex = arr.array('i', [1, 2, 3])
        print("Extend method")
        print("======================")
        print(ex)
        print("Index:      0  1  2 ")
        print("Let\'s extend it with [4, 5, 6]")
        ex.extend([4, 5, 6])
        print(ex)
        print("Index:      0  1  2  3  4  5")
        time.sleep(5)
        add_elements()

    elif opt == "4":
        time.sleep(5)
        main()

# REMOVING ELEMENTS
def remove_elements():
    os.system("clear")
    print("Removing Elements")
    print("======================")
    print("1. Remove\n2. Pop\n3. Back")
    print("======================")
    opt = input("Choose: ")

# REMOVE()
    if opt == "1":
        rem = arr.array('i', [1, 2, 3, 4, 5])
        print("Remove method")
        print("======================")
        print(rem)
        print("Index:      0  1  2  3  4 ")
        print("Let\'s remove number 5 in the elements")
        rem.remove(5)
        print(rem)
        print("Index:      0  1  2  3 ")
        time.sleep(5)
        remove_elements()

# POP()
    elif opt == "2":
        po = arr.array('i', [1, 2, 3, 4, 5, 6])
        print("Pop method")
        print("======================")
        print(po)
        print("Index:      0  1  2  3  4  5 ")
        print("Let\'s insert number 6 in index 5")
        po.pop()
        print(po)
        print("Index:      0  1  2  3  4 ")
        time.sleep(5)
        remove_elements()

    elif opt == "3":
            time.sleep(5)
            main()

# ACCESSING ELEMENTS
def access_elements():
    ac = arr.array('i', [1, 2, 3, 4, 5])
    print("Index method")
    print("======================")
    print(ac)
    print("Index:      0  1  2  3  4")
    print("Let\'s find the index of element number 3")
    print("The index of element number 3 is: ", ac.index(3))
    time.sleep(5)
    main()

# ELEMENT SORTING
def sorting():
    os.system("clear")
    print("Sorting Elements")
    print("======================")
    print("1. Ascending\n2. Descending\n3. Back")
    print("======================")
    opt = input("Choose: ")

# ASCENDING
    if opt == "1":
        asc = arr.array('i', [5, 4, 3, 2, 1])
        print("Ascending")
        print("======================")
        print(asc)
        print("Index:      0  1  2  3  4 ")
        print("Let\'s sort in ascending order")
        print("Original")
        print(asc)
        print("Sorted in ascending order")
        asc.reverse()
        print(asc)
        time.sleep(5)
        sorting()

# DESCENDING
    elif opt == "2":
        de = arr.array('i', [1, 2, 3, 4, 5])
        print("Descending")
        print("======================")
        print(de)
        print("Index:      0  1  2  3  4 ")
        print("Let\'s sort in descending order")
        print("Original")
        print(de)
        print("Sorted in descending order")
        de.reverse()
        print(de)
        print("Index:      0  1  2  3  4 ")
        time.sleep(5)
        sorting()

    elif opt == "3":
            time.sleep(5)
            main()

# MAIN FUNCTION
def main():
    os.system("clear")
    print("Python Arrays Examples")
    print("======================")
    print("1. Adding elements\n2. Removing elements\n3. Accessing elements\n4. Sorting elements\n5. Exit")
    print("======================")
    opt = input("Choose: ")

    if opt == "1":
        add_elements()
    elif opt == "2":
        remove_elements()
    elif opt == "3":
        access_elements()
    elif opt == "4":
        sorting()
    elif opt == "5":
        os.system("clear")
        exit()
        quit()

# EXECUTE MAIN FUNCTION
main()
