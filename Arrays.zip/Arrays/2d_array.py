#!/usr/bin/python3

# LIBRARIES
from array import *
import time
import os

###############################################################
# MULTI DIMENTIONAL ARRAY EXAMPLES BY JAYSON SAN BUENAVENTURA #
###############################################################

# METHOD 1
def ex_1d_m1():
    os.system("clear")
    arr_size = int(input("Enter array lenght: "))
    arr_size = [1]*arr_size
    leng = len(arr_size)
    print("1D Array: ",arr_size)
    print("Lenght: ", leng)
    time.sleep(4)
    main()

# METHOD 2
def ex_1d_m2():
    os.system("clear")
    arr_size = int(input("Enter array lenght: "))
    arr = [0 for i in range(arr_size)]
    print("1D Array using loop: ",arr)
    time.sleep(4)
    main()

# METHOD 1
def ex_2d_m1():
    os.system("clear")
    row = int(input("Enter how namy rows: "))
    col = int(input("Enter how namy columns: "))
    arr = [[0]*col]*row
    leng = len(arr)
    print("2D Array: ",arr)
    print("Lenght: ", leng)
    time.sleep(4)
    main()

# METHOD 2
def ex_2d_m2():
    os.system("clear")
    row = int(input("Enter how namy rows: "))
    col = int(input("Enter how namy columns: "))
    arr = [[0 for i in range(col)] for j in range(row)]
    print("2D Array using loop: ",arr)
    time.sleep(4)
    main()

# MAIN FUNCTION
def main():
    os.system("clear")
    print("Multi-Dimentional Array")
    print("=======================")
    print("1. 1D Array method 1\n2. 1D Array method 2\n3. 2D Array method 1\n4. 2D Array method 3\n5. Exit")
    print("=======================")
    opt = input("Choose: ")

    if opt == "1":
        ex_1d_m1()
    elif opt == "2":
        ex_1d_m2()
    elif opt == "3":
        ex_2d_m1()
    elif opt == "4":
        ex_2d_m2()
    elif opt == "5":
        os.system("clear")
        exit()
        quit()
    else:
        os.system("clear")
        print("Invalid input, try again!")
        time.sleep(2)
        main()

# EXECUTE MAIN FUNCTION
main()
