#!/usr/bin/python3
import os
import array as arr
def arr_no_sort():
    arr = []
    num = int(input(" enter elements: "))
    for i in range(int(num)):
        n = input(" enter value:")
        arr.append(n)
        print(" array: ",arr)


def arr_sort():
    arr = []
    num = int(input(" enter elements: "))
    for i in range(0, num):
        arr.append(int(input(" enter value :")))
        arr.sort()
        print(" array: ",arr)


def methods():
    os.system("clear")
    print(" Choose method")
    print(" 1. without sort")
    print(" 2. with sort")
    print(" 3. exit")


    opt = input(" Choose: ")

    if opt == "1":
        arr_no_sort()
        os.system("sleep 1")
        os.system("clear")
        methods()
    elif opt == "2":
        arr_sort()
        os.system("sleep 1")
        os.system("clear")
        methods()
    else:
        os.system("clear")
        exit()

methods()
