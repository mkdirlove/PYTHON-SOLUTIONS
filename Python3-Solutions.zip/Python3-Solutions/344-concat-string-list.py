# How to concatenate a few strings
# from a list to a single string

data = [
    "This", "is",
    "my", "message"
]

str = " ".join(data)
print(str)
