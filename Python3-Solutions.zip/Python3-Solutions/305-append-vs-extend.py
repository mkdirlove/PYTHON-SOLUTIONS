# append vs extend

a1 = [3, 5, 7]
b1 = [8, 10]
a1.append(b1) # adds one item, a list
print(a1)

a2 = [3, 5, 7]
b2 = [8, 10]
a2.extend(b2) # adds two elements
print(a2) 