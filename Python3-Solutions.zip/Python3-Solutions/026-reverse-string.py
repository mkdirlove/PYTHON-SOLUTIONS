# Reverse a string and print it

str = 'Hello, World!'
rev_str = str[::-1]

print(rev_str)
