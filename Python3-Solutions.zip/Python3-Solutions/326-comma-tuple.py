# Using a trailing comma to
# create a single-element tuple

a = (42) # this is an int
print(type(a))
print(a)

b = (42,) # this is a tuple
# with only one element in it
print(type(b))
print(b)
