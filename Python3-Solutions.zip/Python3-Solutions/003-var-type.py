# different data types
# in the same variable
x = 42
print(x)
print(type(x))

x = "string"
print(x)
print(type(x))