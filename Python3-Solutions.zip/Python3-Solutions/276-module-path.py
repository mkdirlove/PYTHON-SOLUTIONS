# What you can do to see where from
# the module was loaded

import PIL # this module was
# installed via pip
import time # this is a built-in
# module in Python 3

print(PIL) # you will see the path
print(time)
