# How to reverse a list.
# Method 2.

data = [2, 4, 6, 8, 10]
reversed_data = list(reversed(data))

print(data) # original list
print(reversed_data) # reversed list
