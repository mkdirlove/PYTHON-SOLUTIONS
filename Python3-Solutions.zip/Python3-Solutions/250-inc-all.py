# Increment all elements of a list

data = [10, 20, 30, 40, 50, 60]

data = [x + 1 for x in data]
# this is a list comprehension

print(data)