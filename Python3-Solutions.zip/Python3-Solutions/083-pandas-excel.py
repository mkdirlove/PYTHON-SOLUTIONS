import pandas;

data = pandas.read_excel('data.xslx', 'Sheet1')
print(data)
