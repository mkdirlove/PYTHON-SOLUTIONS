# The "len" built-in function

list_var = [1, 2, 3, 4, 5]
str_var = "Hello, World"
dict_var = {"a": 100, "b": 200}

print(len(list_var))
print(len(str_var))
print(len(dict_var))
