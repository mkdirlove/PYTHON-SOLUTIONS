# Going along a list backwards

my_list = ['alpha', 'beta', 'gamma']

# Method 1
for x in my_list[::-1]: 
    print(x)

# Method 2
for y in reversed(my_list):
    print(y)

