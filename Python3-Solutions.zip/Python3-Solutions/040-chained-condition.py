# Chained condition checks

x = 10
y = 20
z = 30

if x < y < z:
    print('OK')
# instead of
# if x < y and y < z