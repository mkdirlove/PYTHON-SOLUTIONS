# Using if, else, and elif

x = int(input('Enter x: '))

if x < 5:
    print('Less than 5')
elif x < 10:
    print('Less than 10')
else:
    print('10 or more')
    