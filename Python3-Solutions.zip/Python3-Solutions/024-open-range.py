# Get the beginning or the end
# of a string using ranges

str = 'abcdefghjiklm'

# beginning
print(str[:5])

# end
print(str[10:])
