# Tuples vs lists
# Similar but different

var1 = [2, 4, 6, 8] # list
var2 = (2, 4, 6, 8) # tuple

print(type(var1))
print(type(var2))
