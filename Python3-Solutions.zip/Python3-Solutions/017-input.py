# Asking the user to enter data

name = input("What's your name? ")
print('Hello, ' + name + '!')
