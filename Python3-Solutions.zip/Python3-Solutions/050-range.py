# Using ranges

my_range = range(1, 5)
print(type(my_range))

print(my_range)

for x in my_range:
    print(x)
