# Why do you need 
# if __name__ == '__main__'?

import testme

print(testme.my_f(5))
# should be 25 but how do you test
# the module and its functions?