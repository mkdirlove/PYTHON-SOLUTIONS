# Find the average value

data = [10, 40, 55, 77, 88, 15]

avg = sum(data) / len(data)

# Python 2:
# avg = sum(data) / float(len(data))

print(avg)
