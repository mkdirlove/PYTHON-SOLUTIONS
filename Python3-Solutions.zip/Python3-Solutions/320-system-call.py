# Calling a system command
# from Python

import os

os.system('date')
