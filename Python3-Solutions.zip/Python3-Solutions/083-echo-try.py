# A simple "echo"
# program

while True:
    try:
        s = input()
        print(s)
    except:
        break
        # Now the program will
        # simply stop after
        # the end of input
        
