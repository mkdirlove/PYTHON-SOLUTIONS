# Open an image
# from a local file

from PIL import Image

img = Image.open('bird.png')
img.show()
