# Let us simplify the code
# by using the "with" keyword.
# Write to a text file

with open('t.txt', 'w') as f:
    f.write('Hello, World!')

# It will be closed automatically