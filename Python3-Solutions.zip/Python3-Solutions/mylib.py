# A function in a module

def f(x):
    return 2 * x