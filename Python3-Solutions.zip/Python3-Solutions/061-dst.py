# Is it daylight savings
# time now?

import time
print(
    time.localtime().tm_isdst
)
