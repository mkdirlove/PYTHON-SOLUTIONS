# Reading a password from
# the keyboard

import getpass

pwd = getpass.getpass('Your pwd: ')

print(pwd) # just to check if 
# that works :-)