# "None" in boolean
# operations

a = True and None
print(a)

b = False or None
print(b)
