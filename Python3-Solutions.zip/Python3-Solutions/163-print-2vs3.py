# A small difference between
# Python 2 and Python 3

message = 'Hello, World!'

# print message
# works in Python 2
# does not work in Python 3

# You need parentheses:
print(message)
