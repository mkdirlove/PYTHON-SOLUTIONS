# Compute the sum of squares
# for the numbers 0 to 10 (incl.)

s = sum(x * x for x in range(11))
print(s)
