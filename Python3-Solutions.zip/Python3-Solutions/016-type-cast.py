# Converting types of variables
# Or type casting (C++ terminology)

a, b = 4, 5
c, d = "4", "5"

print(str(a) + str(b))
print(int(c) + int(d))
