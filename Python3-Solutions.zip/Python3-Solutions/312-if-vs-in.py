# Sometimes you can choose 
# between "if" and "in"

x = 10

if x == 9 or x == 10 or x == 11:
    print('OK')

# Alternatively:
if x in [9, 10, 11]:
    print('Also OK')
