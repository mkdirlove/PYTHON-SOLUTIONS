# Let's print a tree

for i in range(1, 10):
    print('*' * i)

# * repeats a string i times