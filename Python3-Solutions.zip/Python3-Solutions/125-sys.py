# Printing some basic information
# about the operating system
# you are currently working with

import sys

print(sys.platform)
print(sys.version_info)
