# "is" vs "=="

x = 42
y = 42
print(x == y) # True
print(x is y) # True

a = []
b = []
print(a == b) # True
print(a is b) # False
