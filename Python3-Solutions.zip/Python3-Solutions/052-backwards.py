# Counting backwards

for x in range(10, 5, -1):
    print(x)
