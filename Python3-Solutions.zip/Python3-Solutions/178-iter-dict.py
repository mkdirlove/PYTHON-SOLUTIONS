# Iterating over a dictionary is...

data = {
    "France": "Paris",
    "Germany": "Berlin",
    "Italy": "Rome"
}

for x in data:
# for x in data.keys(): # the same
    print(x)
    # what is x?
    # these are the keys