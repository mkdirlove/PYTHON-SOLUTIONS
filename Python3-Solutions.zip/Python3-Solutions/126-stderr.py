# How to write to the
# standard error stream
# (STDERR)

import sys

sys.stderr.write('Hi there!\n')