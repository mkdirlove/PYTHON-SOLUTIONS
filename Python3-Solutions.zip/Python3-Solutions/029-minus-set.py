# "Subtract" one set from
# another

s1 = {'A', 'O', 'E', 'I', 'U'}
s2 = {'K', 'L', 'M', 'N', 'O'}

s3 = s1 - s2
print(s3) # O should go

s4 = s2 - s1
print(s4) # actually, also O
