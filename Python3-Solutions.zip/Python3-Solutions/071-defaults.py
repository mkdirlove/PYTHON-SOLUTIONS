# supplying default values
# for function arguments

def greet(name = 'Dear'):
    print('Hello, ' + name + '!')

greet('John')
greet()
greet('Karla')
