# Using the third parameter
# in a range

str = 'abcdefghjiklm'

# Print every second character
print(str[::2])

# Print every third character
print(str[::3])
