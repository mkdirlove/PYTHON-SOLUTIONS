# Getting the last
# character of a string

str = 'Hello, World!'
#                  ^

print(str[-1])
