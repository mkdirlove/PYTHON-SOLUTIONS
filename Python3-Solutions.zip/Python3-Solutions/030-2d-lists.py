# Multi-dimentional lists

my_list = [
    [1, 3, 5],
    [7, 9, 11],
    [13, 15, 17]
]

print(my_list[1]) # [7, 9, 11]
print(my_list[1][2]) # 11