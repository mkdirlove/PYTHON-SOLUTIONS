# Getting keys and values
# of a dictionary

data = {
    "France": "Paris",
    "Italy": "Rome",
    "Germany": "Berlin"
}

print(data.keys())
print(data.values())

# Values will correspond to the keys
# in the output: they appear in
# the same order