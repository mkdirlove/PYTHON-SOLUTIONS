# Using complex numbers

a = 10+3j # not "i"
b = 9-1j

# Print the distance between
# these two points

print(abs(a - b))
