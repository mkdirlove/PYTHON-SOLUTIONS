# Regular function
# def sqr(x):
#     return x ** 2

# Lambda (inline function)
sqr = lambda x : x ** 2

for i in range(5):
    print(sqr(i))
