# Add indices to the elements
# of a list

data = [
    'alpha', 'beta', 'gamma'
]

data_with_indices = list(
    enumerate(data)
)

print(data_with_indices)
