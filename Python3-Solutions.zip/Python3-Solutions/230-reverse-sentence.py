# Reverse the words in a sentense

text = 'Hello, dear World!'

words = text.split() # split by space
words.reverse()

txet = ' '.join(words)
print(txet) # reversed