# Getting a substring

str = 'Hello, World!'
#      0123456789012
#             ^^^^^

# I want to print "World"

str_world = str[7:12]
print(str_world)
