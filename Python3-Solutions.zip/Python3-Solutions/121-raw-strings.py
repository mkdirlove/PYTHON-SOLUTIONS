# Raw strings in Python

# Regular string:
print('Hello, \nWorld!')

# "Raw" string
# prefixed with "r"
print(r'Hello, \nWorld!')
