# If you are not using
# a variable, e.g., in 
# a loop, use "_"

for _ in range(10):
    print('OK')
