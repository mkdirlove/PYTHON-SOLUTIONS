# Different variants of 
# variable names

# e.g., for the first name

firstname = 'John'  # OK
first_name = 'John' # OK
firstName = 'John' # JavaScript?
FirstName = 'John' # Java?
fiRStNaME = 'John' # hahaha
FIRSTNAME = 'John' # constant?

_first_name = 'John' # hidden
sFirstName = 'John' # Hungarian
                    # notation
                    