# Deleting a variable

x = 42
print(x)

# Now delete it
del(x)
print(x) # will not be able to print