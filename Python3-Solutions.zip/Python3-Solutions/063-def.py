# Creating a simple function

def greet(name):
    print('Hello, ' + name + '!')

greet('John')
greet('Karla')
