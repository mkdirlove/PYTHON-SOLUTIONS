str = '''This is a multi-line
string. That you can continue
on another line pressing the
Enter key'''
print(str)

str2 = '''Notice the spaces
          on the left. Will they
          appear in the output?
'''
print(str2)