# Using "in" to iterate
# over string characters

str = 'Hello, World!'
for ch in str:
    print(ch)
