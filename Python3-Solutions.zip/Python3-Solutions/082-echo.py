# A simple "echo"
# program

while True:
    s = input()
    print(s)
