# The "else" clause can be
# used together with "while"

# If the main condition
# is never met

x = 100
while x < 5:
    print(x)
    x += 1
else:
    print('oops')
