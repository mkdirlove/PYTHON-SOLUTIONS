# Generating and printing
# Fibonacci numbers
# below 100

a, b = 0, 1

while a < 100:
    print(a)
    a, b = b, a + b

# Notice how nice is 
# multiple assignment