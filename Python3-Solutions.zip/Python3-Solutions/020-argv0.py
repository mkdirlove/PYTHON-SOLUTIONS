# What is there in the 0th
# command-line argument?

import sys
whatisthere = sys.argv[0]
print(whatisthere)
