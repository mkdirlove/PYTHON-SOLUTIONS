# Creating a class in Python

class Animal:
    def talk(self):
        print('I am an animal')

# Creating an object or an instance

animal1 = Animal()
animal1.talk()

# Another object of the same class

animal2 = Animal()
animal2.talk()
