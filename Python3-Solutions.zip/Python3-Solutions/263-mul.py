# Same operator, different data
# types

data = [
    123,
    3.3,
    "456",
    [7, 8]
]
for x in data:
    print(x * 2)
    