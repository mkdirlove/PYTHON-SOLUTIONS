# Reading command-line
# arguments

import sys

name = sys.argv[1]
print('Hello, ' + name + '!')
