# Add two numbers from
# command line

a = int(input())
b = int(input())

c = a + b
print(c)
