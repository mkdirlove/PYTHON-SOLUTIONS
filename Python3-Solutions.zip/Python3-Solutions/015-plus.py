# "+" is an overloaded operator.
# It behaves differntly with
# stings and numbers

a, b = 4, 5
s1, s2 = "4", "5"

print(a + b)
print(s1 + s2)
