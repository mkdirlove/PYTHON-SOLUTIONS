# Indexing characters in
# strings

s = 'Hello, World!'
#    01234567...

print(s[0]) # H
print(s[1]) # e
print(s[7]) # W
