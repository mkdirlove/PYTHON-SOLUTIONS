# Ways to create a tuple

t1 = 10, 20, 30
t2 = (10, 20, 30)
t3 = 10, # single element in a tuple
t4 = (10,)
t5 = tuple([10, 20, 30])

print(type(t1))
print(type(t2))
print(type(t3))
print(type(t4))
print(type(t5))
