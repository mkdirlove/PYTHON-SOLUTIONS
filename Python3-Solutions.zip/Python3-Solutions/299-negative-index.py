# Negative indices when accessing
# list elements

data = [
    'alpha', 'beta', 'gamma',
    'delta', 'epsilon'
]

# Accessing the first item:
print(data[0])

# Accessing the last item:
print(data[-1])

# The second to last
print(data[-2])
