# How many bits does your integer
# need in memory?

i = 34
print(i.bit_length())

i = 340
print(i.bit_length())

i = 34238459238539284329572395832
print(i.bit_length())
