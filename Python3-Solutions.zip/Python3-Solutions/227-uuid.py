# Generating random UUIDs

import uuid

for _ in range(10):
    u = uuid.uuid4()
    print(u)
