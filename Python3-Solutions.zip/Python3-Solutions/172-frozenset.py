# Frozen sets

data = [10, 20, 30]

# Create a frozen set
my_set = frozenset(data)
# my_set.add(40) # error

print(my_set)
