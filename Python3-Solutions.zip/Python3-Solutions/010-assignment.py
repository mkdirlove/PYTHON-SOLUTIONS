# Augmenting assignment

x = 41
x += 1
print(x) # gets 42

# x += y is the same as
# x = x + y
