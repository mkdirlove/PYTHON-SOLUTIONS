# Check if the given year is leap

import calendar

year = 2024
is_leap = calendar.isleap(year)
print(is_leap)

