# Using the "while" loop
# in its simplest form

x = 0
while x < 10:
    print(x)
    x += 1
