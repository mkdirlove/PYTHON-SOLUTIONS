# A string that contains
# zero is still True
# in boolean context

s = '0'
if s:
    print('True')
else:
    print('False')
    