# How to reverse a list.

data = [2, 4, 6, 8, 10]
reversed_data = data[::-1]

print(data) # original list
print(reversed_data) # reversed list
