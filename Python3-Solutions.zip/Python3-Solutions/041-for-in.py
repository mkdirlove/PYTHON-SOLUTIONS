# Looping over a tuple
# using "in"

my_data = 3, 5, 7, 9
for x in my_data:
    print(x)

    