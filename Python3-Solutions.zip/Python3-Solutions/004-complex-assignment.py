# non-trivial assignments

x = y = 100
print(x)
print(y)

a, b = 3, 4
print(a)
print(b)
