# Using ranges with strings

str = 'abcdefghjiklmn'

# Characters from 3rd to 5th 
print(str[3:6])
# 6th is not included
