# Creating empty objects

i1 = 0 # integer
i2 = int() # the same

s1 = '' # string
s2 = str()

l1 = [] # list
l2 = list()

d1 = {} # dictionary
d2 = dict()

set1 = set() # set
# set2 = {} # No, as it is a dict