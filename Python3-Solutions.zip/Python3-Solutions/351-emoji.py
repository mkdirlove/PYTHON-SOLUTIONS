from emoji import emojize

print(emojize(':bus: :house:'))

print(emojize(':phone:',
    use_aliases=True))