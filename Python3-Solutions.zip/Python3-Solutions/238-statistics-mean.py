# Another method of calculating
# the average value: using
# modules

import statistics

data = [10, 40, 55, 77, 88, 15]

avg = statistics.mean(data)
print(avg)
