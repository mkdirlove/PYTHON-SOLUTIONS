# Here's a module

def my_f(x):
    return x ** 2
# You can run it from command line!

if __name__ == '__main__':
    if my_f(5) == 25:
        print('OK')
    else:
        print('Not OK')