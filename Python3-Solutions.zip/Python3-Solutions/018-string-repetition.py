# The "*" operator is also 
# redefined (overloaded)
# for strings

str = 'A'
long_str = str * 15
print(long_str)
