# Examining the third parameter of
# ranges

r = range(1, 10, 2)
#                ^ 2 is a step

# Let's convert it to a list
# and print the result

a = list(r)
print(a)
# Every second number will be printed