# Using "in"

# with strings
print('s' in 'Water')
print('s' in 'Wasser')

# with lists
my_list = [1, 2, 3, 4, 5]
print(4 in my_list)

# with sets
my_set = {1, 2, 3, 4, 5}
print(4 in my_set)
