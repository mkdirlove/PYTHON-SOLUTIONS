# How to split a string to
# characters

str = 'Hello, World!'

# First, print a character
print(str[3])

# Now, make a list out of a string
# Just convert a type:
chars = list(str)
print(type(chars))
print(chars[3])
