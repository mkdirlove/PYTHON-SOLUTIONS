# To skip the rest of the
# loop body, use "continue"

x = 0
while x < 5:
    x += 1
    if x == 3:
        continue
    print(x)
