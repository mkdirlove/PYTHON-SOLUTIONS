# Multiple assignment with a star

a, *b, c = 1, 2, 3, 4, 5, 6

print(a) # 1
print(b) # [2, 3, 4, 5]
print(c) # 6
