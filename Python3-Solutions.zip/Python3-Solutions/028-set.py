# Sets

set_var = {1, 2, 3, 1, 4, 5, 4}
print(type(set_var))

# A set can contain each
# value only once
print(set_var)
