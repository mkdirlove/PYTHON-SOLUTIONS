# You have some module, and 
# you want to see if you are
# importing it from a correct
# location

import mylib

print(mylib.__file__)
# Prints the path to the module