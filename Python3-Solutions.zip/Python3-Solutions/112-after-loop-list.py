# Looking at the loop variable
# after the loop is over

colours = ['red', 'green', 'blue']
for c in colours:
    print(c)

print('After the loop: ' + c)
