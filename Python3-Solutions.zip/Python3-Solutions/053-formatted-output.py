name = 'John'
print('Hello, ' + name + '!')

# Using string formatting

# Old style
print('Hello, %s!' % name)

# New style
print('Hello, {}!'.format(name))
