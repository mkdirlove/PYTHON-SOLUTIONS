# Remove duplicates from a list

data = [3, 5, 6, 3, 6, 8, 7, 8]

data = list(set(data))
print(data)
