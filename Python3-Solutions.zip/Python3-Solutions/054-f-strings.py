# "f-strings" or
# string interpolation
# (available in Python 3.6+)

name = 'John'
print(f'Hello, {name}!')

