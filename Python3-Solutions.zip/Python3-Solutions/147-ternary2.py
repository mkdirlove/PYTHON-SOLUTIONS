# Let's see another paradigm
# you can use with conditional
# statements

for i in range(1, 5):
    # is i odd or even?
    # oe = 'odd' if i % 2 else 'even'
    print('odd') if i % 2 else print('even')
    # print(f'{i} is {oe}')
