# The second parameter of "round"

x = 30.1415926

print(round(x)) # rounds to 30

print(round(x, 1)) # plus one digit
                   # after "."
print(round(x, 2)) # two digits, etc.
print(round(x, 4))

print(round(1.203, 2)) # 1.2