import secrets

for _ in range(5):
    print(secrets.randbelow(1000))