# variables
x = 42
print(x)

y = 43
print(y)
