# How does the "+" operator
# work with lists?

a = [1, 3, 5]
b = [7, 9, 11]
c = a + b
print(c)
