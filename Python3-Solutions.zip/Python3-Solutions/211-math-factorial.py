# Computing a factorial
# using library functions

import math

for i in range(1, 10):
    f = math.factorial(i)
    print(f'{i}! = {f}')
