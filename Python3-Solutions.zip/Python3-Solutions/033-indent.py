# Be careful with indentation
# in, for example, "if" blocks

if 100 > 1000:
    print('100 > 1000???')
print('100 > 1000!')
