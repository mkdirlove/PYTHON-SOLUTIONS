# Randomizing lists

import random

data = [10, 20, 30, 40, 50, 60]

random.shuffle(data) # in-place

print(data)
