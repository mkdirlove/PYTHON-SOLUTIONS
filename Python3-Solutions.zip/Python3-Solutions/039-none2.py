# When working with "None",
# order is important

print(False and None)
print(None and False)

